# Log Rotators

 - support multiple logs aggregation
